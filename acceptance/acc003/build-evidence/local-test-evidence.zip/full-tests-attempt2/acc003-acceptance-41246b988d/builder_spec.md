# ACC003 builder specification — normative input/output semantics

Implement one independent R script invoked as `Rscript --vanilla main.R INPUT_CSV OUTPUT_DIR`. Use base R and digest; do not import any peer code, harness or oracle. Create all five output CSVs, including on invalid input. Do not hardcode expected IDs/results. Errors in the runtime itself may exit nonzero; invalid data is a typed result, not a runtime crash.

Input is UTF-8 without BOM, LF terminated, no CR/NUL/embedded newline, standard CSV quotes/doubled quotes. Header is `id,amount,eligible`, optionally followed by ONE distinct nonempty unused column with ANY name. Ignore that column's values after parsing. Required columns remain first and in that order. Reject wrong field counts, malformed quotes, duplicate IDs, unknown eligible tokens or invalid amounts. IDs match `[A-Za-z0-9_-]+` and are case sensitive. Eligible tokens are exactly `true` and `false`. Amount is blank (missing) or a full-token decimal matching `[+-]?(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?`, parsed as finite binary64. Reject whitespace, NaN, Inf and overflow. Do not trim/coerce invalid tokens. Underflow follows R's binary64 parser.

Qualify if eligible true and nonmissing amount >=10, without epsilon. Exclusion precedence: NOT_ELIGIBLE, then AMOUNT_MISSING, then BELOW_THRESHOLD; otherwise QUALIFIED. Rank qualifiers by amount descending then ASCII ID ascending, select first two. Sum selected amounts sequentially in rank order, starting at zero. Empty valid selection has zero counts/sum. Numeric output is round-trip binary64 text (e.g. 17 significant digits); missing numeric is literal `NA`, not zero or an empty string. Input bytes' SHA256 is lowercase hex. Use `case_key=fixture` in aggregate outputs for every input.

The supplied builder_contract.json lists exact headers, keys, exact/numeric fields and missingness. Output CSV column order below is fixed; quote as needed; textual JSON arrays are CSV-escaped. Output LF terminated without BOM.

1. `audit_rows.csv`: id,eligible_state,amount_state,qualification,reason_code,selection_state,raw_amount,amount_value. One row per input ID, ID ascending. eligible_state TRUE/FALSE; amount_state PRESENT/MISSING; qualification YES/NO; selection_state SELECTED/NOT_SELECTED; raw_amount preserves its decoded source token; amount_value is parsed value or NA.
2. `reason_totals.csv`: reason_code,row_n. Four rows in ASCII reason order: AMOUNT_MISSING, BELOW_THRESHOLD, NOT_ELIGIBLE, QUALIFIED, including zero counts.
3. `rank_rows.csv`: id,place_state,rank_n,amount_value. Qualifiers only, ID ascending; place_state SELECTED or WAITLISTED; rank_n is the amount/ID rank starting at one.
4. `totals.csv`: case_key,calculation_state,source_n,eligible_true_n,qualified_n,selected_n,selected_sum. One row; calculation_state EVALUATED. Eligible count includes eligible rows with missing amount.
5. `build_report.csv`: case_key,build_state,data_state,qualified_ids,selected_ids,source_digest,qualified_n,selected_n,selected_sum. One row. Valid input: EVALUATED/PRESENT, qualified_ids compact JSON string array in ASCII ID order, selected_ids compact JSON string array in ranking order, empty arrays `[]`.

Invalid input: files 1–4 contain headers only; file 5 has build_state INVALID_INPUT, data_state UNKNOWN, qualified_ids and selected_ids literal `null`, numeric fields literal NA, source_digest the actual bytes' SHA256. An unreadable input is UNVERIFIABLE/UNKNOWN with the same unknown fields and source_digest literal `null`.

Only your own failed input and output may be sent back for repairs. Do not seek the peer implementation or its results. Return the complete script in one R code block and a brief declaration of tools/model used and whether any peer solution was seen. Odd surrounding formatting is not an analytical failure; missing or truncated code must be recaptured.


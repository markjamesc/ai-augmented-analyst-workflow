SELECT id, category, amount FROM practice ORDER BY id

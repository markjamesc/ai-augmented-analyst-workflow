a<-commandArgs(TRUE)
code<-system2(file.path(R.home('bin'),if(.Platform$OS.type=='windows')'Rscript.exe' else 'Rscript'),c('--vanilla',shQuote("/workspace/scratch/300679a5be94/build-progress/full-tests-attempt3/acc003-acceptance-4158ed3895/analysis/r_a/main.R"),shQuote(a[1]),shQuote(a[2])))
if(code!=0)quit(status=code)
p<-file.path(a[2],'totals.csv');x<-read.csv(p,colClasses='character',na.strings=character());if(nrow(x)>0){x$selected_sum[1]<-'999';write.csv(x,p,row.names=FALSE,na='NA')}

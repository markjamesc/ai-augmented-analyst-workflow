One question: reproduce the frozen selection rule and detect planted defects. Eight synthetic rows; capacity two; no model.

SELECT id, category, amount FROM practice WHERE category='x' UNION ALL SELECT id, category, amount FROM practice WHERE category='x'

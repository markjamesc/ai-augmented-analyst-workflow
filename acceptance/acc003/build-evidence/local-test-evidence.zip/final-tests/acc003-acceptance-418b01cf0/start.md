SYNTHETIC STAKEHOLDER: accept or remediate the mechanical workflow. No real business decision; no deadline affects the rule.
